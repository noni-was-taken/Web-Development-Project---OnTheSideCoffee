function changeMenu(menuToShowId) {
    const drinksMenu = document.getElementById('drinksMenu');
    const foodMenu = document.getElementById('foodMenu');
    const dessertMenu = document.getElementById('dessertMenu');


    drinksMenu.classList.add('display');
    foodMenu.classList.add('display');
    dessertMenu.classList.add('display');

    const menuToShow = document.getElementById(menuToShowId);
    if (menuToShow) {
        menuToShow.classList.remove('display');
    }
}